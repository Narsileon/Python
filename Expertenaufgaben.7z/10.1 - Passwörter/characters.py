import string

UPPERCASES = list(string.ascii_uppercase) 
LOWERCASES = list(string.ascii_lowercase)
DIGITS = list(string.digits)
SYMBOLS = list("!#$%&'()*+,-./:;<=>?@[\]^_`{|}~")

CHARACTERS = UPPERCASES + LOWERCASES + DIGITS + SYMBOLS
